<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>register</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
<div class="card fat">
		<div class="card-body mx-auto">
			<h4 class="card-title">Register</h4>
			<form method="POST" class="my-login-validation" novalidate="">
				<div class="form-group">
					<label for="email">Email</label>
					<input id="email" type="email" class="form-control" name="email" value="" required autofocus>
					<div class="invalid-feedback">
						Email is invalid
					</div>
					</div>

					<div class="form-group">
						<label for="password">Password
						</label>
						<input id="password" type="password" class="form-control" name="password" required data-eye>
						<div class="invalid-feedback">
							Password is required
						</div>
					</div>
                    <div class="form-group">
						<label for="username">Username
						</label>
						<input id="username" type="username" class="form-control" name="username" required data-eye>
						<div class="invalid-feedback">
							Username is required
						</div>
					</div>
                    <div class="form-group">
						<label for="phone">Phone Number
						</label>
						<input id="phone" type="phone" class="form-control" name="phone" required data-eye>
						<div class="invalid-feedback">
							Phone Number is required
						</div>
					</div>
					<div class="form-group">
						<div class="custom-checkbox custom-control">
							<input type="checkbox" name="remember" id="remember" class="custom-control-input">
							<label for="remember" class="custom-control-label">Remember Me</label>
                        
				    	</div>
					</div>

					<div class="form-group m-0">
						<button type="submit" class="btn btn-primary btn-block" name="btnregis">
							Register
						</button>
					</div>
					<div class="mt-4 text-center">
						Already have an account? <a href="login.php">login</a>
					</div>
					</form>

					<?php
					require "koneksi.php";
                    
					if(isset($_POST['btnregis'])){
                        $sql = "SELECT * FROM anggota";
                        $query = mysqli_query($koneksi, $sql);
						
                        $newemail = $_POST['email'];
						$newpassword = $_POST['password'];
                        $newusername = $_POST['username'];
                        $newphone = $_POST['phone'];
                        
                        while($row = mysqli_fetch_array($query)){
                        $username = $row['username'];
                        $password = $row['password'];
                        $phone = $row['phone'];
                        $email = $row['email'];
                        }  
                        if($newemail==$email){
                            echo"Email Sudah terdaftar";
                        }
                        else{
						$sql = "INSERT INTO anggota (email, password, username, phone) VALUES ( '$newemail', '$newpassword', '$newusername', '$newphone');";
                        } 



	
                    }

	

	
				?>
				</div>
			</div>
</body>
</html>